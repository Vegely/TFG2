The KAT folder is organized as follows:

├── Level 1: PQCkemKAT_BIKE_3114.req
├── Level 1: PQCkemKAT_BIKE_3114.rsp
├── Level 3: PQCkemKAT_BIKE_6198.req
├── Level 3: PQCkemKAT_BIKE_6198.rsp
├── Level 5: PQCkemKAT_BIKE_10276.rsp
├── Level 5: PQCkemKAT_BIKE_10276.rsp
└── README.txt

1 directory, 5 files

The BIKE additional implementations are being made available in the following repositories:

- Software Additional Implementation developed by Nir Drucker, Shay Gueron, and Dusan Kostic: https://github.com/awslabs/bike-kem 

- Hardware Additional Implementation developed by Jan Richter-Brockmann, Ming-Shing Chen, Santosh Ghosh and Tim Guneysu: https://github.com/Chair-for-Security-Engineering/BIKE



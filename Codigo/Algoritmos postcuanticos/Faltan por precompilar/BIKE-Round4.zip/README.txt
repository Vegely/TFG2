                      BIKE - Bit-Flipping Key Encapsulation

                            https://bikesuite.org
--------------------------------------------------------------------------------

Authors in alphabetical order:
* Nicolas Aragon -- Univ Rennes, Inria, IRISA, France
* Paulo S. L. M. Barreto -- Univ. of Washington Tacoma, USA
* Slim Bettaieb -- Worldline, France
* Loïc Bidoux -- Worldline, France
* Olivier Blazy -- University of Limoges, France
* Jean-Christophe Deneuville -- ENAC, University of Toulouse, France
* Philippe Gaborit -- University of Limoges, France
* Santosh Ghosh -- Intel, USA
* Shay Gueron -- Univ. of Haifa, Israel; AWS, USA
* Tim Güneysu -- Ruhr-Universitat Bochum, Germany; DFKI, Germany
* Carlos Aguilar Melchor -- University of Toulouse, France
* Rafael Misoczki -- Google, USA
* Edoardo Persichetti -- Florida Atlantic University, USA
* Jan Richter-Brockmann -- Ruhr-Universitat Bochum, Germany
* Nicolas Sendrier -- INRIA, France
* Jean-Pierre Tillich -- INRIA, France
* Valentin Vasseur -- INRIA, France
* Gilles Zémor -- IMB, University of Bordeaux, France

--------------------------------------------------------------------------------

The BIKE 4-th round submission package is organized as follows:

├── Supporting_Documentation
├── Reference_Implementation
├── Additional_Implementations
├── KAT
└── README.txt

4 directories, 1 file

